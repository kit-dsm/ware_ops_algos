/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_histogram_global extends algoritmos_timeWindow {

    double threshold = 0.5;
    double avg_pesos_n = 0;
    double dv_pesos_n = 0;
    double lambda=0;
    int n_muestras = 0;
    int max_peso = 0;
    int[] histograma_pesos_n;
    int contadorMejoras = 0;
    double eficacia = 0;

    public timeWindow_probability_histogram_global(Warehouse wh, algoritmos alg_routing, double threshold) {
        super(wh, alg_routing);
        this.threshold = threshold;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {
        
        if(LB.size()>1){
            return true;
        }
        
        //long mediana = Math.round(Math.log(2)/this.lambda);
        long media = Math.round(1/this.lambda);
        
        //long time = System.currentTimeMillis();
        
        BatchCollected BCo = new BatchCollected(batchToRouting, wh);
        double t_routing = BCo.routing(alg_routing);
        
        if(t_routing<media){
            return true;
        }
        
              
        
        double peso_resto = batchToRouting.max_peso - batchToRouting.peso;
        //if(peso_resto>max_peso){
        //    new throw Exception("Error: Error peso de articulos: timeWindow_probability_histogram_global");
        //}
        int ocurrencias =0;
        for(int a=0; a<Math.round(peso_resto); a++){
            ocurrencias += histograma_pesos_n[a];
        }
        
        double porcen = ocurrencias / n_muestras;
        
        if(porcen < threshold){
            return true;
        }
        
        contadorMejoras++;
        
        double efic = t_routing/batchToRouting.peso;
        
        eficacia += efic;
        
        double eficaciaMedia = eficacia/contadorMejoras;

        return !(efic<(eficaciaMedia*1.1));

    }

    public void load_stad(List<Order> LO, long tiempo_ejecucion) {
        
        
        this.lambda= LO.size()/tiempo_ejecucion;

        if (avg_pesos_n == 0) {
            avg_pesos_n = 0;
            dv_pesos_n = 0;
            n_muestras = LO.size();
            max_peso = 0;

            for (int i = 0; i < LO.size(); i++) {
                Order o = LO.get(i);
                avg_pesos_n += o.getPeso();
                if (max_peso < Math.round(o.getPeso())) {
                    max_peso = Math.round(o.getPeso());
                }
            }
            avg_pesos_n /= LO.size();
            //for (int i = 0; i < LO.size(); i++) {
            //    Order o = LO.get(i);
            //    dv_pesos_n += Math.abs(avg_pesos_n - o.getPeso());
            //}
            //dv_pesos_n /= LO.size();

            histograma_pesos_n = new int[Math.round(wh.getCapacidad_trabajador())+1];
            for (int i = 0; i < LO.size(); i++) {
                Order o = LO.get(i);
                histograma_pesos_n[Math.round(o.getPeso()) - 1]++;
            }

        }

    }

}
