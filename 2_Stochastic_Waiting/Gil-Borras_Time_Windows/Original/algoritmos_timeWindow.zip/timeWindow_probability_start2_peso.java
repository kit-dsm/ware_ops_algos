/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_start2_peso extends algoritmos_timeWindow {

    double threshold = 0.3;
    double avg_pesos_n = 0;
    double dv_pesos_n = 0;

    public timeWindow_probability_start2_peso(Warehouse wh, algoritmos alg_routing, double threshold) {
        super(wh, alg_routing);
        this.threshold = threshold;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        double peso_resto = batchToRouting.max_peso - batchToRouting.peso;
        double porcen = peso_resto / (avg_pesos_n + dv_pesos_n);

        return porcen < threshold;

    }

    public void load_stad(List<Order> LO) {

        avg_pesos_n = 0;
        dv_pesos_n = 0;

        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            avg_pesos_n += o.getPeso();
        }
        avg_pesos_n /= LO.size();
        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            dv_pesos_n += Math.abs(avg_pesos_n - o.getPeso());
        }
        dv_pesos_n /= LO.size();
    }

}
