/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_start extends algoritmos_timeWindow {

    double threshold = 0.3;
//    double avg_llegada = 0;
//    double avg_pesos = 0;
//    double dv_llegada = 0;
//    double dv_pesos = 0;
    double avg_mejora = 0;
    int n_mejora = 0;

    long time_left = System.currentTimeMillis();

    double avg_pesos_n = 0;
    double dv_pesos_n = 0;

    double avg_routing = 0;

    double tasa_old = Double.MAX_VALUE;

    public timeWindow_probability_start(Warehouse wh, algoritmos alg_routing, double threshold) {
        super(wh, alg_routing);
        this.threshold = threshold;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {
        boolean res = true;
        double porcen = 1;

        double peso_resto = batchToRouting.max_peso - batchToRouting.peso;
        double n_med = batchToRouting.max_peso / avg_pesos_n;
        if (avg_pesos_n + dv_pesos_n - peso_resto < 0) {
            porcen *= 1;
        } else if (avg_pesos_n + dv_pesos_n - peso_resto < n_med) {
            porcen *= 0.8;
        } else if (avg_pesos_n + dv_pesos_n - peso_resto < 2 * n_med) {
            porcen *= 0.6;
        } else {
            porcen *= 0.4;
        }

        BatchCollected BC = new BatchCollected(batchToRouting, wh);
        double routing = BC.routing(alg_routing);
        double tasa = routing / batchToRouting.peso;
        if (tasa_old < Double.MAX_VALUE) {
            n_mejora++;
            if (tasa <= tasa_old) {
                avg_mejora++;
            }
            porcen *= avg_mejora / n_mejora;
        }

        if (time_left + avg_routing + routing <= System.currentTimeMillis()) {
            porcen = 0;
        } else if (time_left + avg_routing <= System.currentTimeMillis()) {
            porcen *= 0.5;
        } else if (time_left + routing <= System.currentTimeMillis()) {
            porcen *= 0.5;
        } else {
            porcen *= 1;
        }

        // 1 -> no sale
        // 0 -> sale
        
        if (porcen > threshold) {
            res = false;
        }

        if (res) {
            avg_routing = (avg_routing + routing) / 2;
            tasa_old = Double.MAX_VALUE;
            time_left = System.currentTimeMillis();
            if (avg_mejora * 3 < n_mejora) {
                avg_mejora = 1;
                n_mejora = 1;
            }
        } else {
            tasa_old = tasa;
        }
        return res;
    }

    public void load_stad(List<Order> LO) {

        avg_pesos_n = 0;
        dv_pesos_n = 0;

        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            avg_pesos_n += o.getPeso();
        }
        avg_pesos_n /= LO.size();
        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            dv_pesos_n += Math.abs(avg_pesos_n - o.getPeso());
        }
        dv_pesos_n /= LO.size();
    }
}
