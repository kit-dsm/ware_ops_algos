/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_Zhang extends algoritmos_timeWindow {

    double time = 0;
    int alfa = 0;
    boolean load_paratemers = false;
    double lambda = 0.1;
    List<Order> Orders_iniciales;
    long start = System.currentTimeMillis();

    public timeWindow_Zhang(Warehouse wh, algoritmos alg_routing, int alfa) {
        super(wh, alg_routing);
        this.alfa = alfa;
        start = System.currentTimeMillis();
    }

    public void setLambda(double lambda) {
        this.lambda = lambda;
    }

    public void setOrders_iniciales(List<Order> Orders_iniciales) {
        this.Orders_iniciales = Orders_iniciales;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {
        double Wt = 0;
        for (int i = 0; i < Orders_iniciales.size(); i++) { //(Order order : Orders_iniciales2) {
            Order order = Orders_iniciales.get(i);
            Wt += order.getPeso();
        }
        Wt = Wt / Orders_iniciales.size();

        double tb = (wh.getCapacidad_trabajador() / Wt) * lambda;
        long end = start + Math.round(((alfa * tb) / 2) * 60000); // El calculo del lambda es en minutos..

        if (end > System.currentTimeMillis()) {
            return false;
        } else {
            start = System.currentTimeMillis();
            return true;
        }
    }

}
