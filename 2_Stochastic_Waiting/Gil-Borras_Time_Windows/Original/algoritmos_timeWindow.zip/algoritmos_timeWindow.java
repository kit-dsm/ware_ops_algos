/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author rasta
 */
public abstract class algoritmos_timeWindow implements Serializable {

    Warehouse wh;
    public algoritmos alg_routing;

    public algoritmos_timeWindow(Warehouse wh, algoritmos alg_routing) {
        this.wh = wh;
        this.alg_routing = alg_routing;
    }

    public abstract boolean run(List<Batch> LB, Batch batchToRouting) throws Exception;
}
