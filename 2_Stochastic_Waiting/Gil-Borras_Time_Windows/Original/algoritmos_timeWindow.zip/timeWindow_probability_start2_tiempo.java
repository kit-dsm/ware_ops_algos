/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_start2_tiempo extends algoritmos_timeWindow {

    long time_left = System.currentTimeMillis();
    double avg_routing = 0;
    double dv_routing = 0;
    double threshold = 0.3;
    int nBatches = 1;

    public timeWindow_probability_start2_tiempo(Warehouse wh, algoritmos alg_routing, double threshold, int nBatches) {
        super(wh, alg_routing);
        this.threshold = threshold;
        this.nBatches = nBatches;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        if (LB.size() > nBatches) {

            return true;

        } else {
            BatchCollected BC = new BatchCollected(batchToRouting, wh);
            double routing = BC.routing(alg_routing);

            long time = System.currentTimeMillis() - time_left;

            double porcen = time / (2 * (avg_routing + dv_routing));

            boolean res = Math.abs(porcen - 1) < threshold;

            if (res) {
                avg_routing = (avg_routing + routing) / 2;
                dv_routing = (dv_routing + Math.abs(avg_routing - routing)) / 2;
                time_left = System.currentTimeMillis();
            }
            return res;
        }
    }

}
