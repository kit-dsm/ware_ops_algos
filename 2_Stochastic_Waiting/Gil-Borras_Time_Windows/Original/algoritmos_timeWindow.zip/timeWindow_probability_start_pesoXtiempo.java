/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_start_pesoXtiempo extends algoritmos_timeWindow {

    long time_left = System.currentTimeMillis();
    double avg_routing = 0;

    double avg_pesos_n = 0;
    double dv_pesos_n = 0;

    public timeWindow_probability_start_pesoXtiempo(Warehouse wh, algoritmos alg_routing) {
        super(wh, alg_routing);
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {
        boolean res = true;

        BatchCollected BC = new BatchCollected(batchToRouting, wh);
        double routing = BC.routing(alg_routing);

        if (time_left + avg_routing + routing <= System.currentTimeMillis()) {
            res = true;
        } else if (time_left + avg_routing <= System.currentTimeMillis()) {
            res = (Math.random() > 0.5);
        } else if (time_left + routing <= System.currentTimeMillis()) {
            res = (Math.random() > 0.5);
        } else {
            res = false;
        }

        if (!res) {
            double peso_resto = batchToRouting.max_peso - batchToRouting.peso;
            double n_med = batchToRouting.max_peso / avg_pesos_n;
            if (avg_pesos_n + dv_pesos_n < peso_resto) {
                res = true;
            } else if (avg_pesos_n < peso_resto) {
                res = (Math.random() > 0.5);
            } else if (avg_pesos_n + dv_pesos_n - peso_resto < 2 * n_med) {
                res = false;
            }
        }

        if (res) {
            avg_routing = (avg_routing + routing) / 2;
            time_left = System.currentTimeMillis();
        }

        return res;
    }

    public void load_stad(List<Order> LO) {

        avg_pesos_n = 0;
        dv_pesos_n = 0;

        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            avg_pesos_n += o.getPeso();
        }
        avg_pesos_n /= LO.size();
        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            dv_pesos_n += Math.abs(avg_pesos_n - o.getPeso());
        }
        dv_pesos_n /= LO.size();
    }

}
