/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_henn extends algoritmos_timeWindow {

    double time = 0;
    double alfa = 0;

    public timeWindow_henn(Warehouse wh, algoritmos alg_routing, double alfa) {
        super(wh, alg_routing);
        this.alfa = alfa;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        time = System.currentTimeMillis();

        if (LB.isEmpty()) {
            return false;
        } else if (LB.size() == 1) {
            Batch b = LB.get(0);
            Order oi = b.getOrderMaxserviceTime(wh, alg_routing);
            BatchCollected BCo = new BatchCollected(batchToRouting, wh);
            double t_routing = BCo.routing(alg_routing);
            double threshold = ((1 + alfa) * oi.tiempo_llegada) + (alfa * oi.serviceTime) - t_routing;
            return (time > threshold);
        } else {
            return true;
        }

    }

}
