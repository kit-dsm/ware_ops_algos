/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import gvns_obp_1.helpers;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_fix_time extends algoritmos_timeWindow {

    int nMinutes = 1;
    long time = 0;

    public timeWindow_fix_time(Warehouse wh, algoritmos alg_routing, int nMinutes) {
        super(wh, alg_routing);
        this.nMinutes = nMinutes;
        this.time = System.currentTimeMillis() + (120000 * nMinutes);
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        if (this.time <= System.currentTimeMillis()) {
            this.time = System.currentTimeMillis() + (60000 * nMinutes) + helpers.calculateFuncionObjetivo_distancia_routing(batchToRouting, wh, alg_routing);
            return true;
        } else {
            return false;
        }
    }
}
