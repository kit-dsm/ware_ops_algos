/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import gvns_obp_1.helpers;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_fix_orders extends algoritmos_timeWindow {

    int nOrders = 1;

    public timeWindow_fix_orders(Warehouse wh, algoritmos alg_routing, int nOrders) {
        super(wh, alg_routing);
        this.nOrders = nOrders;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        if (helpers.numeroPedidos(LB) >= nOrders) {
            return true;
        } else {
            return false;
        }
    }
}
