/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_fix_arrivePicker extends algoritmos_timeWindow {

    public timeWindow_fix_arrivePicker(Warehouse wh, algoritmos alg_routing) {
        super(wh, alg_routing);
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        return true;
    }
}
