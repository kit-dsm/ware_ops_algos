/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Order;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_probability_start2 extends algoritmos_timeWindow {

    long time_left = System.currentTimeMillis();
    double avg_routing = 0;
    double dv_routing = 0;
    double threshold = 0.3;
    double avg_pesos_n = 0;
    double dv_pesos_n = 0;
    double avg_mejora = 0;
    int n_mejora = 0;
    double tasa_old = Double.MAX_VALUE;

    public timeWindow_probability_start2(Warehouse wh, algoritmos alg_routing, double threshold) {
        super(wh, alg_routing);
        this.threshold = threshold;
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        // PESO
        double peso_resto = batchToRouting.max_peso - batchToRouting.peso;
        double porcen = peso_resto / (avg_pesos_n + dv_pesos_n);

        //TIEMPO
        BatchCollected BC = new BatchCollected(batchToRouting, wh);
        double routing = BC.routing(alg_routing);
        long time = System.currentTimeMillis() - time_left;
        double porcen2 = time / (2 * (avg_routing + dv_routing));

        //MEJORAS
        double porcen3 = 1;

        double tasa = routing / batchToRouting.peso;
        if (tasa_old < Double.MAX_VALUE) {
            n_mejora++;
            if (tasa <= tasa_old) {
                avg_mejora++;
            }
            porcen3 = avg_mejora / n_mejora;
        }

        //boolean res = (Math.abs(porcen2 - 1) * porcen * porcen3) < threshold;
        boolean res = (Math.abs(porcen2 - 1) + porcen + porcen3)/3 < threshold;

        if (res) {
            avg_routing = (avg_routing + routing) / 2;
            dv_routing = (dv_routing + Math.abs(avg_routing - routing)) / 2;
            time_left = System.currentTimeMillis();
            tasa_old = Double.MAX_VALUE;
            avg_mejora = 1;
            n_mejora = 1;
        } else {
            tasa_old = tasa;
        }

        return res;

    }

    public void load_stad(List<Order> LO) {

        avg_pesos_n = 0;
        dv_pesos_n = 0;

        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            avg_pesos_n += o.getPeso();
        }
        avg_pesos_n /= LO.size();
        for (int i = 0; i < LO.size(); i++) {
            Order o = LO.get(i);
            dv_pesos_n += Math.abs(avg_pesos_n - o.getPeso());
        }
        dv_pesos_n /= LO.size();
    }

}
