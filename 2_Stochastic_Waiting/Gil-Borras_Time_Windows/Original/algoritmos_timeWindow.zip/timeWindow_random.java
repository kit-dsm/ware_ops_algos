/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gvns_obp_1.algoritmos_timeWindow;

import gvns_obp_1.Batch;
import gvns_obp_1.BatchCollected;
import gvns_obp_1.BatchCollected.algoritmos;
import gvns_obp_1.Warehouse;
import java.util.List;

/**
 *
 * @author rasta
 */
public class timeWindow_random extends algoritmos_timeWindow {

    long time;
    long wait = 0;

    public timeWindow_random(Warehouse wh, algoritmos alg_routing) {
        super(wh, alg_routing);
        time = System.currentTimeMillis();
    }

    @Override
    public boolean run(List<Batch> LB, Batch batchToRouting) throws Exception {

        if (wait == 0) {
            BatchCollected BC = new BatchCollected(batchToRouting, wh);
            double routing = BC.routing(alg_routing);
            wait = Math.round(2 * routing * Math.random());
            return false;
        } else if (wait + time < System.currentTimeMillis()) {
            BatchCollected BC = new BatchCollected(batchToRouting, wh);
            double routing = BC.routing(alg_routing);
            wait = Math.round(2 * routing * Math.random());
            time = System.currentTimeMillis();
            return true;
        } else {
            return false;
        }
    }
}
